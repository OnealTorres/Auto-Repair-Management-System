--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE arms_db;
--
-- Name: arms_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE arms_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Philippines.1252';


ALTER DATABASE arms_db OWNER TO postgres;

\connect arms_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: create_invoice(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_invoice() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF (SELECT COUNT(*) FROM INVOICE WHERE book_id = old.book_id)<1 AND new.book_status='Finished' THEN
		INSERT INTO INVOICE (book_id) VALUES (old.book_id);
	END IF;
	RETURN NEW;
	
END;
$$;


ALTER FUNCTION public.create_invoice() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book (
    book_id integer NOT NULL,
    book_type character varying(50) NOT NULL,
    book_status character varying(20) DEFAULT 'Pending'::character varying NOT NULL,
    book_total numeric(10,2) DEFAULT 0 NOT NULL,
    book_vcl_plate character varying(20) NOT NULL,
    book_vcl_brand character varying(50) NOT NULL,
    book_vcl_model character varying(50) NOT NULL,
    date_created timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    date_updated timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    emp_id integer NOT NULL,
    cus_id integer NOT NULL,
    srv_id integer NOT NULL,
    book_start timestamp without time zone NOT NULL,
    book_end timestamp without time zone NOT NULL,
    book_details character varying(100)
);


ALTER TABLE public.book OWNER TO postgres;

--
-- Name: book_book_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.book_book_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.book_book_id_seq OWNER TO postgres;

--
-- Name: book_book_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.book_book_id_seq OWNED BY public.book.book_id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    cus_id integer NOT NULL,
    cus_fname character varying(25) NOT NULL,
    cus_mname character varying(25),
    cus_lname character varying(25) NOT NULL,
    cus_mobile character varying(11) NOT NULL,
    cus_email character varying(50) NOT NULL,
    cus_sex character(6) NOT NULL,
    cus_address character varying(150) NOT NULL,
    cus_status character varying(10) DEFAULT 'Active'::character varying NOT NULL,
    date_created timestamp without time zone DEFAULT CURRENT_DATE NOT NULL,
    date_updated timestamp without time zone DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_cus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.customer ALTER COLUMN cus_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.customer_cus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    emp_id integer NOT NULL,
    emp_fname character varying(25) NOT NULL,
    emp_mname character varying(25),
    emp_lname character varying(25) NOT NULL,
    emp_sex character(6) NOT NULL,
    emp_dob date NOT NULL,
    emp_email character varying(50) NOT NULL,
    emp_password character varying(50),
    emp_address character varying(150) NOT NULL,
    emp_mobile character varying(11) NOT NULL,
    emp_status character varying(10) DEFAULT 'Active'::character varying NOT NULL,
    emp_type character varying(20) NOT NULL,
    date_created timestamp without time zone DEFAULT CURRENT_DATE,
    date_updated timestamp without time zone DEFAULT CURRENT_DATE,
    emp_service character varying(50) NOT NULL
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: employee_emp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.employee ALTER COLUMN emp_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.employee_emp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice (
    inv_id integer NOT NULL,
    date_created timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    date_updated timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    book_id integer
);


ALTER TABLE public.invoice OWNER TO postgres;

--
-- Name: invoice_inv_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.invoice ALTER COLUMN inv_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.invoice_inv_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service (
    srv_id integer NOT NULL,
    srv_name character varying(50) NOT NULL,
    srv_category character varying(50) NOT NULL,
    srv_time character varying(10) NOT NULL,
    srv_fee numeric(10,2) NOT NULL,
    srv_type character varying(20) NOT NULL
);


ALTER TABLE public.service OWNER TO postgres;

--
-- Name: service_srv_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.service ALTER COLUMN srv_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.service_srv_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shop (
    shop_id integer NOT NULL,
    shop_name character varying(100) DEFAULT 'SHOP NAME'::character varying NOT NULL,
    shop_address character varying(150) DEFAULT 'SHOP ADDRESS'::character varying NOT NULL,
    shop_email character varying(50) DEFAULT 'admin'::character varying NOT NULL,
    shop_password character varying(50) DEFAULT 'admin'::character varying NOT NULL,
    shop_owner character varying(100) DEFAULT 'SHOP OWNER'::character varying NOT NULL,
    shop_mobile character varying(11) DEFAULT 'MOBILE'::character varying NOT NULL,
    shop_telephone character varying(20) DEFAULT 'TELEPHONE'::character varying NOT NULL,
    shop_socials character varying(150) DEFAULT 'SOCIALS'::character varying NOT NULL
);


ALTER TABLE public.shop OWNER TO postgres;

--
-- Name: shop_shop_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shop_shop_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shop_shop_id_seq OWNER TO postgres;

--
-- Name: shop_shop_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shop_shop_id_seq OWNED BY public.shop.shop_id;


--
-- Name: book book_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book ALTER COLUMN book_id SET DEFAULT nextval('public.book_book_id_seq'::regclass);


--
-- Name: shop shop_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop ALTER COLUMN shop_id SET DEFAULT nextval('public.shop_shop_id_seq'::regclass);


--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book (book_id, book_type, book_status, book_total, book_vcl_plate, book_vcl_brand, book_vcl_model, date_created, date_updated, emp_id, cus_id, srv_id, book_start, book_end, book_details) FROM stdin;
\.
COPY public.book (book_id, book_type, book_status, book_total, book_vcl_plate, book_vcl_brand, book_vcl_model, date_created, date_updated, emp_id, cus_id, srv_id, book_start, book_end, book_details) FROM '$$PATH$$/3391.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (cus_id, cus_fname, cus_mname, cus_lname, cus_mobile, cus_email, cus_sex, cus_address, cus_status, date_created, date_updated) FROM stdin;
\.
COPY public.customer (cus_id, cus_fname, cus_mname, cus_lname, cus_mobile, cus_email, cus_sex, cus_address, cus_status, date_created, date_updated) FROM '$$PATH$$/3385.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (emp_id, emp_fname, emp_mname, emp_lname, emp_sex, emp_dob, emp_email, emp_password, emp_address, emp_mobile, emp_status, emp_type, date_created, date_updated, emp_service) FROM stdin;
\.
COPY public.employee (emp_id, emp_fname, emp_mname, emp_lname, emp_sex, emp_dob, emp_email, emp_password, emp_address, emp_mobile, emp_status, emp_type, date_created, date_updated, emp_service) FROM '$$PATH$$/3389.dat';

--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice (inv_id, date_created, date_updated, book_id) FROM stdin;
\.
COPY public.invoice (inv_id, date_created, date_updated, book_id) FROM '$$PATH$$/3393.dat';

--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service (srv_id, srv_name, srv_category, srv_time, srv_fee, srv_type) FROM stdin;
\.
COPY public.service (srv_id, srv_name, srv_category, srv_time, srv_fee, srv_type) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: shop; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shop (shop_id, shop_name, shop_address, shop_email, shop_password, shop_owner, shop_mobile, shop_telephone, shop_socials) FROM stdin;
\.
COPY public.shop (shop_id, shop_name, shop_address, shop_email, shop_password, shop_owner, shop_mobile, shop_telephone, shop_socials) FROM '$$PATH$$/3383.dat';

--
-- Name: book_book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.book_book_id_seq', 6, true);


--
-- Name: customer_cus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_cus_id_seq', 2, true);


--
-- Name: employee_emp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_emp_id_seq', 4, true);


--
-- Name: invoice_inv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoice_inv_id_seq', 1, true);


--
-- Name: service_srv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_srv_id_seq', 3, true);


--
-- Name: shop_shop_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shop_shop_id_seq', 1, true);


--
-- Name: book book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_pkey PRIMARY KEY (book_id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (cus_id);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (emp_id);


--
-- Name: invoice invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (inv_id);


--
-- Name: service service_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT service_pkey PRIMARY KEY (srv_id);


--
-- Name: shop shop_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop
    ADD CONSTRAINT shop_pkey PRIMARY KEY (shop_id);


--
-- Name: invoice unique_book_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT unique_book_id UNIQUE (book_id);


--
-- Name: book trg_create_invoice; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_create_invoice AFTER UPDATE ON public.book FOR EACH ROW EXECUTE FUNCTION public.create_invoice();


--
-- Name: book book_cus_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_cus_id_fkey FOREIGN KEY (cus_id) REFERENCES public.customer(cus_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: book book_emp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_emp_id_fkey FOREIGN KEY (emp_id) REFERENCES public.employee(emp_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: book book_srv_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_srv_id_fkey FOREIGN KEY (srv_id) REFERENCES public.service(srv_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoice invoice_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.book(book_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

